<pre>
<?php
var_dump($_REQUEST);die;