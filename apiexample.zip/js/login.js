$(function () {
    var my_window;
    function findGetParameter(parameterName) {
        var result = null,
            tmp = [];
        location.search
            .substr(1)
            .split("&")
            .forEach(function (item) {
                tmp = item.split("=");
                if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
            });
        return result;
    }
    if(findGetParameter('code')){
        my_window.clone();
    }
    var dd = console.log;
    var passport = {
        client_id: 5,
        client_secret: 'wAV2ECU6JPqhQ5ZVIegIBBqTAiqPuQf41DUlloda',

    }
    var grand = {
        access_token: {
            url: 'http://bestbetter.loc/oauth/token',
            grant_type: 'client_credentials',
            client_id: passport.client_id,
            client_secret: passport.client_secret,
            scope: '',
        },
        login: {
            url: 'http://bestbetter.loc/oauth/authorize',
            data: {
                'client_id': passport.client_id,
                'redirect_uri': 'http://apitest.loc/callback.php',
                // 'access_token':null,
                'response_type': 'code',
                'scope': '*'
            }
        },
        refreshToken: {
            'grant_type': 'refresh_token',
            'refresh_token': 'the-refresh-token',
            client_id: passport.client_id,
            client_secret: passport.client_secret,
            'scope': '',
        },
        get_access_token: {
            'grant_type': 'authorization_code',
            'client_id': 'client-id',
            'client_secret': 'client-secret',
            'redirect_uri': 'http://example.com/callback',
            'code': null,
        }
    }
    var accessToken = function (success) {
        console.log(success);
        request = success;
    };
    postSendAjax = function (url, data, success, error) {
        $.ajax({
            type: 'post',
            url: url,
            cache: false,
            datatype: "json",
            data: data,
            success: function (data) {
                if (success) {
                    success(data);
                }
                return data;
            },
            error: function (errorThrown) {
                if (error) {
                    error(errorThrown);
                }
                return errorThrown;
            }
        });
    };


    var request = {};

    var access_token = postSendAjax(grand.access_token.url, grand.access_token, accessToken);


    $('body').on('click', '.oauth-login', function () {
        loginForm();
    });

    function loginForm() {
        // grand.login.data.access_token = request.access_token;
        // dd(grand.login.data,request);
       // window.location = grand.login.url + '?' + $.param(grand.login.data);
        my_window=window.open(grand.login.url + '?' + $.param(grand.login.data), "popupWindow", "width=600,height=600,scrollbars=yes");
    }
});