<?php

/**
 * Created by PhpStorm.
 * User: Ara Arakelyan
 * Date: 7/18/2017
 * Time: 6:41 PM
 */

namespace Btybug\btybug\Services;

abstract class GeneralService
{

}