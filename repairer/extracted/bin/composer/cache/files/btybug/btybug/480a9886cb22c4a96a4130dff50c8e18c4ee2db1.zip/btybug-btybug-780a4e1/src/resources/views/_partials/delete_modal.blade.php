<div class="modal fade" id="delete_item" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="delete_item_label">Delete Item</h4>
            </div>
            <div class="modal-body">
                <a class="btn btn-default" data-dismiss="modal">Cancel</a>
                <a id="item_modal_delete_button" class="btn btn-danger" data-slug="empty" data-url="empty">Delete</a>
            </div>
        </div>
    </div>
</div>