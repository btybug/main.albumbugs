<div class="hidden withoutifreamsetting animated bounceInRight settingmodal">
    <div style="position: relative;">
        <div class="custom-panel-title">Title</div>
        <a href="#" class="closeIcon pull-right" data-dismiss="modal">
            <i class="fa fa-close"></i></a>
    </div>
    <hr/>
    <div class="custom-panel-body"></div>
</div>