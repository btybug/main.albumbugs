<?php
defined('MASTER_CLASSIFIER') or define('MASTER_CLASSIFIER', 'all-classify');
defined('MASTER_TAG') or define('MASTER_TAG', 'all-tags');
defined('SUPERADMIN') or define('SUPERADMIN', 'superadmin');
defined('SUPERADMIN_ID') or define('SUPERADMIN_ID', 1);