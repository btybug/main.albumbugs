@extends('btybug::layouts.mTabs',['index'=>'backend_gears'])
<!-- Nav tabs -->
@section('tab')
@stop