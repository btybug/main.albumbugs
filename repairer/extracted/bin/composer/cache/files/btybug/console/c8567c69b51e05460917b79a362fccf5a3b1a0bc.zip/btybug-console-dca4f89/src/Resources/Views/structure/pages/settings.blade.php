@extends('btybug::layouts.admin')
@section('content')
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 buttons page-data p-20">
        @include('console::structure.pages._partials.page-data')
    </div>
@stop