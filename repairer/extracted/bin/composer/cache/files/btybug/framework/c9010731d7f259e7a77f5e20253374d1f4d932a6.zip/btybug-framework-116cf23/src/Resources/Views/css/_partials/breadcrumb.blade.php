<div class="d1">
    <h2>Breadcrumb</h2>
    <div class="col-md-12">
        <h4>Breadcrumb 1</h4>
        <h5>bty-breadcrumb-1</h5>
        <div class="bty-breadcrumb-1">
            <a href="#" class="active">Browse</a>
            <a href="#">Compare</a>
            <a href="#">Order Confirmation</a>
            <a href="#">Checkout</a>
        </div>
    </div>
    <div class="col-md-12">
        <h4>Breadcrumb 2</h4>
        <h5>bty-breadcrumb-2</h5>
        <div class="bty-breadcrumb-2">
            <ol>
                <li><a href="#">Browse</a></li>
                <li><a href="#">Compare</a></li>
                <li><a href="#">Order</a></li>
                <li><a href="#">Checkout</a></li>
            </ol>
        </div>
    </div>
    <div class="col-md-12">
        <h4>Breadcrumb 3</h4>
        <h5>bty-breadcrumb-3</h5>
        <div class="bty-breadcrumb-3">
            <ul>
                <li><a href="#">Browse</a></li>
                <li><a href="#">Compare</a></li>
                <li><a href="#">Order</a></li>
                <li><a href="#">Checkout</a></li>
                <li><a href="#">Checkout</a></li>
            </ul>
        </div>
    </div>
</div>