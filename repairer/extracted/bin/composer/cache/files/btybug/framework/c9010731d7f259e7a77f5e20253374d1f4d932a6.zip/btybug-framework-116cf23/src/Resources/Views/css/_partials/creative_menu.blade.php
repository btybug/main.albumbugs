<div class="d1">
    <h2>Creative menus</h2>
    <div class="col-md-12">
        <h4>Creative menu 1</h4>
        <h5>bty-creative-menu-1</h5>
        <div class="col-md-12">
            <input class="burger-check-1" id="burger-check-1" type="checkbox">
            <label for="burger-check-1" class="burger-1"></label>
            <div class="bty-creative-menu-1">
                <div>
                    <div>
                        <h6>Menu 1</h6>
                        <p>Description 1</p>
                    </div>
                    <div>
                        <div class="col-md-12">
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div>
                        <h6>Menu 2</h6>
                        <p>Description 2</p>
                    </div>
                    <div>
                        <div class="col-md-12">
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
                <div>
                    <div>
                        <h6>Menu 3</h6>
                        <p>Description 3</p>
                    </div>
                    <div>
                        <div class="col-md-12">
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div>
                        <h6>Menu 4</h6>
                        <p>Description 4</p>
                    </div>
                    <div>
                        <div class="col-md-12">
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a>
                                    <i class="fa fa-wrench"></i>
                                    <span>Tile 0</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <h4>Creative menu 2</h4>
        <h5>bty-creative-menu-2</h5>
        <div class="bty-creative-menu-2">
            <h6 onclick="void(0);">Menu</h6>
            <ol>
                <li><a href="#">Menu 1</a>
                    <ol onclick="void(0);">
                        <li><a href="#">Menu 1.1</a></li>
                        <li><a href="#">Menu 1.2</a></li>
                        <li><a href="#">Menu 1.3</a></li>
                    </ol>
                </li>
                <li><a href="#">Menu 2</a></li>
                <li><a href="#">Menu 3</a></li>
                <li><a href="#">Menu 4</a></li>
                <li><a href="#">Menu 5</a></li>
            </ol>
        </div>
    </div>
    <div class="col-md-12">
        <h4>Creative menu 3</h4>
        <h5>bty-creative-menu-3</h5>
        <div class="col-md-12">
            <input class="burger-check" id="burger-check" type="checkbox">
            <label for="burger-check" class="burger"></label>
            <div class="bty-creative-menu-3">
                <ul>
                    <li><a href="#">
                            <i class="fa fa-wrench"></i>
                            <span>Tile 0</span>
                        </a>
                    </li>
                    <li><a href="#">
                            <i class="fa fa-wrench"></i>
                            <span>Click</span>
                        </a>

                    </li>
                    <li><a href="#">
                            <i class="fa fa-wrench"></i>
                            <span>Tile 0</span>
                        </a>
                    </li>
                    <li><a href="#">
                            <i class="fa fa-wrench"></i>
                            <span>Tile 0</span>
                        </a>
                    </li>
                </ul>
                <div>
                    <div><i class="fa fa-arrow-left" aria-hidden="true"></i></div>
                    <ul>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <h4>Creative menu 4</h4>
        <h5>bty-creative-menu-4</h5>
        <div class="col-md-12">
            <div class="bty-creative-menu-4-icon"><i class="fa fa-bars" aria-hidden="true"></i></div>
            <div class="bty-creative-menu-4">
                <ul>
                    <li><a href="#">
                            <i class="fa fa-wrench"></i>
                            <span>Tile 0</span>
                        </a>
                    </li>
                    <li><a href="#">
                            <i class="fa fa-wrench"></i>
                            <span>Click</span>
                        </a>

                    </li>
                    <li><a href="#">
                            <i class="fa fa-wrench"></i>
                            <span>Tile 0</span>
                        </a>
                    </li>
                    <li><a href="#">
                            <i class="fa fa-wrench"></i>
                            <span>Tile 0</span>
                        </a>
                    </li>
                </ul>
                <div>
                    <div><i class="fa fa-arrow-left" aria-hidden="true"></i></div>
                    <ul>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                        <li><a href="#">
                                <i class="fa fa-cab"></i>
                                <span>Sub 0</span>
                            </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>