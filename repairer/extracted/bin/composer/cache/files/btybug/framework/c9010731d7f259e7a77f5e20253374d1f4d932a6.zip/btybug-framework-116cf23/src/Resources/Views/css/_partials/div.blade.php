<div class="d1">
    <h2>Div</h2>
    <div class="col-md-12">
        <h5>bty-div-border</h5>
        <div class="bty-div-border">

        </div>
        <h5>bty-div-bg</h5>
        <div class="bty-div-bg">

        </div>
        <h5>bty-div-hover</h5>
        <div class="bty-div-hover">

        </div>
    </div>
</div>