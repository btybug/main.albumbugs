<div class="d1">
    <h2>HR</h2>
    <div class="col-md-12">
        <h4>Hr style 1</h4>
        <h5>bty-hr-1</h5>
        <hr class="bty-hr-1">
        <br>
        <h4>Hr style 2</h4>
        <h5>bty-hr-2</h5>
        <hr class="bty-hr-2">
        <br>
        <h4>Hr style 3</h4>
        <h5>bty-hr-3</h5>
        <hr class="bty-hr-3">
        <br>
        <h4>Hr style 4</h4>
        <h5>bty-hr-4</h5>
        <hr class="bty-hr-4">
        <br>
        <h4>Hr style 5</h4>
        <h5>bty-hr-5</h5>
        <hr class="bty-hr-5">
        <br>
        <h4>Hr style 6</h4>
        <h5>bty-hr-6</h5>
        <hr class="bty-hr-6">
        <br>
        <h4>Hr style 7</h4>
        <h5>bty-hr-7</h5>
        <hr class="bty-hr-7">
        <br>
        <h4>Hr style 8</h4>
        <h5>bty-hr-8</h5>
        <hr class="bty-hr-8">
        <br>
        <h4>Hr style 9</h4>
        <h5>bty-hr-9</h5>
        <hr class="bty-hr-9">
        <br>
        <h4>Hr style 10</h4>
        <h5>bty-hr-10</h5>
        <hr class="bty-hr-10">
    </div>
</div>