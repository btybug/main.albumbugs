<div class="d1">
    <h2>Textarea</h2>
    <div class="col-md-12">
        <h4>Textarea 1</h4>
        <h5>bty-textarea-1</h5>
        <textarea placeholder="This is an placeholder box" class="bty-textarea-1"></textarea>
    </div>
    <div class="col-md-12">
        <h4>Textarea 2</h4>
        <h5>bty-textarea-2</h5>
        <textarea placeholder="This is an placeholder box" class="bty-textarea-2"></textarea>
    </div>
    <div class="col-md-12">
        <h4>Textarea 3</h4>
        <h5>bty-textarea-3</h5>
        <textarea placeholder="This is an placeholder box" class="bty-textarea-3"></textarea>
    </div>

</div>