<?php
/**
 * Created by PhpStorm.
 * User: Comp1
 * Date: 5/22/2017
 * Time: 2:07 PM
 */

namespace Btybug\FrontSite\Models;


use app\Models\BaseModel;

class FormTest extends BaseModel
{

}