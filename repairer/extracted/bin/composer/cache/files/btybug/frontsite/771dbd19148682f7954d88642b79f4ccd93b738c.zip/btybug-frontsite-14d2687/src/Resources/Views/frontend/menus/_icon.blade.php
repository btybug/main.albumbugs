<div class="form-group">
    <label class="col-sm-3 control-label" for="editicon">Icon</label>

    <div class="col-sm-9">
        <a href="#" class="btn btn-default btn-sm" id="icons">Edit</a>
        <span class="iconView" data-iconSeting="">No Icon</span>
        <input type="text" hidden="hidden" id="geticonPlacement">
        <input type="text" name="icon" id="geticonseting">
    </div>
</div>

              
