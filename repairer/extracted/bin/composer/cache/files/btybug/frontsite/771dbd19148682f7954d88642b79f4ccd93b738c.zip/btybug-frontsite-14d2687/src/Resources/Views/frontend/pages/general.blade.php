@extends('btybug::layouts.mTabs',['index'=>'page_edit'])
@section('tab')
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 buttons page-data p-20">
        @include('manage::frontend.pages._partials.page_data_general')
    </div>
@stop