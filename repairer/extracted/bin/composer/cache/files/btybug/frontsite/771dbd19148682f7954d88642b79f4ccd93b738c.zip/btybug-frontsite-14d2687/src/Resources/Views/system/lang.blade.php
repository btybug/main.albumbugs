@extends('btybug::layouts.mTabs',['index'=>'manage_settings'])
@section('tab')
    lang
@stop
@section('CSS')
@stop

@section('JS')
@stop
