@extends('btybug::layouts.mTabs',['index'=>'manage_settings'])
@section('tab')
    URL manager
@stop

