@extends('cms::layouts.mTabs',['index'=>'module_settings'])
@section('tab')
    {!! "This is Media Settings Page" !!}
@stop