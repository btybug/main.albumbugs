<?php

namespace Btybug\Resources\Models;

use Illuminate\Database\Eloquent\Model;

class Assest extends Model
{

}
