<?php
/**
 * Created by PhpStorm.
 * User: Edo
 * Date: 8/3/2016
 * Time: 8:45 PM
 */

namespace App\Models\Forms;

class Fields
{

}