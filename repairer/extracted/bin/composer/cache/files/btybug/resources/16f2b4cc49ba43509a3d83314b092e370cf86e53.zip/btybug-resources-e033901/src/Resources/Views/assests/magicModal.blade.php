<div style="z-index: 99999" class="modal fade bigfullModal " id="magic-settings" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close btn-red-close " data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                <h4 class="modal-title p-t-10" id="myModalLabel">
                </h4>
            </div>
            <div class="modal-body" style="min-height: 500px;">

                <div id="magic-body">


                </div>

            </div>
        </div>
    </div>
</div>
</div>



