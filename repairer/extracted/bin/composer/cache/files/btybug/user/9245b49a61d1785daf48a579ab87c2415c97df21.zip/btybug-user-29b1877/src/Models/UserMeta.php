<?php
/**
 * Created by PhpStorm.
 * User: Comp2
 * Date: 31-Mar-17
 * Time: 15:57
 */

namespace Btybug\User\Models;


use Illuminate\Database\Eloquent\Model;

class UserMeta extends Model
{

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users_meta';
}