{!! sc('getCoreForm',["id" =>9, "url" => '/admin/users/groups']) !!}
