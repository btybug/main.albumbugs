@extends('layouts.admin')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <h2>Edit User</h2>
        </div>
        <div class="row">
            [edit-form slug=user_edit_form edit=id]

        </div>
    </div>
@stop

