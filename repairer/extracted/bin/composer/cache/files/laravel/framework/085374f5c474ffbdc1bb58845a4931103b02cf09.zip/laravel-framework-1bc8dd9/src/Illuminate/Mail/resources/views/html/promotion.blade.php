<table class="promotion" align="center" width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td align="center">
            {{ Illuminate\Mail\Markdown::parse($slot) }}
        </td>
    </tr>
</table>
