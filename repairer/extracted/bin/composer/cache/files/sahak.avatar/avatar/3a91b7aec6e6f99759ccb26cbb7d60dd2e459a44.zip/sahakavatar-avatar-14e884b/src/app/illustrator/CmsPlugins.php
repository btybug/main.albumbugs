<?php

namespace Avatar\Avatar\illustrator;

/**
 * Created by PhpStorm.
 * User: menq
 * Date: 8/4/17
 * Time: 11:20 PM
 */

class CmsPlugins
{
    public function modules()
    {
        // TODO: Implement modules() method.
    }

    public function plugins()
    {
        // TODO: Implement plugins() method.
    }

    private function pluginsReader()
    {

    }

    private function modulesReader()
    {

    }
}