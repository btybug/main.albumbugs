<?php


namespace Composer\Installer;


class InstallerEvents
{


    const PRE_DEPENDENCIES_SOLVING = 'pre-dependencies-solving';


    const POST_DEPENDENCIES_SOLVING = 'post-dependencies-solving';
}
