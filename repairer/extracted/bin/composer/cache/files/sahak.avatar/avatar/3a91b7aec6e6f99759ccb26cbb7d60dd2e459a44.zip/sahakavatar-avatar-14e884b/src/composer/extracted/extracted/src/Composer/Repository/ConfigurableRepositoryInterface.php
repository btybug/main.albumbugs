<?php


namespace Composer\Repository;


interface ConfigurableRepositoryInterface
{
    public function getRepoConfig();
}
