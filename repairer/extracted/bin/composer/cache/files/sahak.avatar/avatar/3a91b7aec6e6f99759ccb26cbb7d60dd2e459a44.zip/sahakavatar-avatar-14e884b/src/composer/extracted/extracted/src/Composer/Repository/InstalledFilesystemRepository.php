<?php


namespace Composer\Repository;


class InstalledFilesystemRepository extends FilesystemRepository implements InstalledRepositoryInterface
{
}
