<?php


namespace Composer\Script;


class CommandEvent extends Event
{
}
