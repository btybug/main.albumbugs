<div class="sidebar-nav navbar-collapse lefthtmlnav" id="side-menu">

</div>
