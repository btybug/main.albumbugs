@extends('cms::layouts.mTabs',['index'=>'backend_gears'])
<!-- Nav tabs -->
@section('tab')
@stop