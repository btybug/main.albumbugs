@extends('cms::layouts.mTabs',['index'=>'backend_console'])
@section('tab')
    Layouts
@stop
@section('CSS')
@stop
@section('JS')
@stop