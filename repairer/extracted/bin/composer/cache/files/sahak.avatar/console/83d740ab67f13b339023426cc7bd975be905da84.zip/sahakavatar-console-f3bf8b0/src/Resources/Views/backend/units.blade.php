@extends('cms::layouts.mTabs',['index'=>'backend_console'])
@section('tab')
    Units
@stop
@section('CSS')
@stop
@section('JS')
@stop