@extends('cms::layouts.mTabs',['index'=>'backend_console'])
@section('tab')
    Views
@stop
@section('CSS')
@stop
@section('JS')
@stop