@extends('layouts.admin')
@section('content')
    <div>
        Console Module
    </div>
@stop
@section('CSS')
@stop
@section('JS')
@stop

