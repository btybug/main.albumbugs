@extends('cms::layouts.mTabs',['index'=>'structure_console'])
@section('tab')
    classify
@stop
@section('CSS')
@stop
@section('JS')
@stop