@extends('cms::layouts.mTabs',['index'=>'structure_console'])
@section('tab')
    urls
@stop
@section('CSS')
@stop
@section('JS')
@stop