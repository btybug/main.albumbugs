<tr class="appendet-forms-lists">
    <td>
        <div class="p-b-5"> Trigger/Form</div>
        {!! Form::select('trigger_on_form',['Select Form'] + $forms,null,['class'=>'form-control']) !!}

    </td>
</tr>
