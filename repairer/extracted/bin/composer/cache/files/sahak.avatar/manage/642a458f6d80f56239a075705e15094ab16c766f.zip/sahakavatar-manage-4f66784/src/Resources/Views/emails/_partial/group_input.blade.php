<li class="list-group-item" data-id="{!! $group->id !!}"><a
            href="{!! url('/admin/manage/emails',$group->id) !!}"> {!! $group->name !!} </a><span class="listtool"><a
                href="#" class="btn btn-default" data-action="editGroup" data-id="4" data-title="common"><i
                    class="fa fa-pencil" aria-hidden="true"></i></a> <a href="#" class="btn btn-default"
                                                                        data-action="deleteGroup" data-id="4"><i
                    class="fa fa-trash-o" aria-hidden="true"></i></a></span>
</li>