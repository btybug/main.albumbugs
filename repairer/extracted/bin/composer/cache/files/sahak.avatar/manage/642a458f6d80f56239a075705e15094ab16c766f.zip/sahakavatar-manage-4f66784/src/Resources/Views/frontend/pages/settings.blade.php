@extends('cms::layouts.mTabs',['index'=>'page_edit'])
@section('tab')
    @include('manage::frontend.pages._partials.page-data')
@stop