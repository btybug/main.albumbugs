@extends('cms::layouts.admin')
@section('content')
    <div>
        Manage structure
    </div>
@stop
@section('CSS')
@stop
@section('JS')
@stop

