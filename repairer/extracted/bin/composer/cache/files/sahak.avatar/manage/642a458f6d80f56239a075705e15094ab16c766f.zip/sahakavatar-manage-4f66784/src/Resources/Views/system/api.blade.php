@extends('cms::layouts.mTabs',['index'=>'manage_settings'])
@section('tab')
    api
@stop
@section('CSS')
@stop

@section('JS')
@stop
