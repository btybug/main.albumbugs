@extends('cms::layouts.mTabs',['index'=>'manage_settings'])
@section('tab')
    Notification
@stop
@section('CSS')
@stop

@section('JS')
@stop
