@extends('cms::layouts.mTabs',['index'=>'manage_settings'])
@section('tab')
    URL manager
@stop

