<article>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 articles_large">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 ">
                <div class="articles">
                    <div class="">
                        <img src="{!!  url('\resources\assets\images\pic_2.png') !!}" alt="image">
                    </div>
                    <div class="bottom">
                        <a href="#">
                            <h1>Layout 002_variaton 001</h1>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-4 col-xl-4">
                <div class="articles">
                    <div class="">
                        <img src="{!!  url('\resources\assets\images\pic_1.png') !!}" alt="image">
                    </div>
                    <div class="bottom">
                        <a href="#">
                            <h1>Layout 002_variaton 002</h1>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
                <div class="articles">
                    <div class="">
                        <img src="{!!  url('\resources\assets\images\pic_3.png') !!}" alt="image">
                    </div>
                    <div class="bottom">
                        <a href="#">
                            <h1>Layout 002_variaton 003</h1>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 articles_large">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 ">
                <div class="articles">
                    <div class="">
                        <img src="{!!  url('\resources\assets\images\pic_2.png') !!}" alt="image">
                    </div>
                    <div class="bottom">
                        <a href="#">
                            <h1>Layout 002_variaton 001</h1>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-4 col-xl-4">
                <div class="articles">
                    <div class="">
                        <img src="{!!  url('\resources\assets\images\pic_1.png') !!}" alt="image">
                    </div>
                    <div class="bottom">
                        <a href="#">
                            <h1>Layout 002_variaton 002</h1>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
                <div class="articles">
                    <div class="">
                        <img src="{!!  url('\resources\assets\images\pic_3.png') !!}" alt="image">
                    </div>
                    <div class="bottom">
                        <a href="#">
                            <h1>Layout 002_variaton 003</h1>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</article>
{!!  HTML::style($tplPath.'/css/style.css') !!}
