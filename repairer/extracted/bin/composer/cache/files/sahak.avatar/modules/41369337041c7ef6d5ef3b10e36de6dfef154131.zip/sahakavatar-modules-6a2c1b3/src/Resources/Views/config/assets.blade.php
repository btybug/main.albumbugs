@extends('layouts.admin')
@section('content')
    assets
@stop
@section('JS')

@stop
