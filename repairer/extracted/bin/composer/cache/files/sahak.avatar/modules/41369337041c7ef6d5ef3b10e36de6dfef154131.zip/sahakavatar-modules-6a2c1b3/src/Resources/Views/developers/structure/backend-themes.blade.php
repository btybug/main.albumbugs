@extends('cms::layouts.mTabs',['index'=>'developers_structure'])
@section('tab')
    Themes
@stop
@section('JS')

@stop
