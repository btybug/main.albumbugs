@extends('cms::layouts.mTabs',['index'=>'developers_structure'])
@section('tab')
    FORMS
@stop
@section('JS')

@stop
