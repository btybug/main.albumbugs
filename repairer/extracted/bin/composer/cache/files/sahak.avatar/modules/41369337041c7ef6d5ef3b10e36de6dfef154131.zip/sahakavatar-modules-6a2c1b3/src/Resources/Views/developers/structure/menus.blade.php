@extends('cms::layouts.mTabs',['index'=>'developers_structure'])
@section('tab')
    Menus
@stop
@section('JS')

@stop
