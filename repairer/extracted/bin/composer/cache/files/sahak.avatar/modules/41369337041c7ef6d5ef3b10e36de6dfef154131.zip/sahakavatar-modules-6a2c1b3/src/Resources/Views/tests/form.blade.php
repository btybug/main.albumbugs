@extends('layouts.admin')
@section('content')
    {!! $form->render() !!}
@stop