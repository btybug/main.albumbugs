<?php
/**
 * Created by PhpStorm.
 * User: Sahak
 * Date: 8/3/2016
 * Time: 8:45 PM
 */

namespace App\Modules\Resources\Models\Forms;


use App\Modules\Resources\Models\Forms\Abstracts\BaseForms;

class Forms extends BaseForms
{

}