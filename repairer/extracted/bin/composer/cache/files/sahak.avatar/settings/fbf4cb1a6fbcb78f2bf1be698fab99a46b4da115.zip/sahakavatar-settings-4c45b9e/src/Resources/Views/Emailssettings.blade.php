@extends('layouts.admin')
@section('content')

    {!! 'this is Emails module settings page' !!}

@stop
@section('CSS')

@stop
@section('JS')

@stop

