<div class="m-10 p-15 bg-white overflow-y-hidden">
    <div class="col-sm-6">
        {!! Form::select('template_id',$templates,null,['class'=>'form-control']) !!}
    </div>
</div>
