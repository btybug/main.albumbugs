<div class="text-left previewtitle"><strong>Preview</strong></div>
<input class="file" type="file" id="fileupload">
<div id="errorBlock" class="help-block"></div>
