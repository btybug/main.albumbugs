@extends('cms::layouts.mTabs',['index'=>'backend_settings'])
<!-- Nav tabs -->
@section('tab')

@stop
