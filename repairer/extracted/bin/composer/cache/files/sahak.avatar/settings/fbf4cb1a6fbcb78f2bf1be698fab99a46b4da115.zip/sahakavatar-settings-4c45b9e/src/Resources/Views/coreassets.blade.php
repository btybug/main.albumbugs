@extends('layouts.admin')
@section('content')
    coreassets
@stop
