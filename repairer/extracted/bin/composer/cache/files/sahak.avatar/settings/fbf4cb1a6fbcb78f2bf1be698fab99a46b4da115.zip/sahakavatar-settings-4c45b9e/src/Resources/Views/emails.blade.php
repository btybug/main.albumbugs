@extends('layouts.admin')
@section('content')

    {!! 'this is Settings addon simple page' !!}

@stop
@section('CSS')

@stop
@section('JS')

@stop

