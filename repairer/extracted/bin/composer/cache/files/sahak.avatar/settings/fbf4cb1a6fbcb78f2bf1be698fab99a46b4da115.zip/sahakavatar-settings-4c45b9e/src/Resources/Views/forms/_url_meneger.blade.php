<fieldset>


    <!-- Prepended checkbox -->
    <div class="form-group">
        <label class="col-md-4 control-label" for="prependedcheckbox">Defoult</label>
        <div class="col-md-6">
            <div class="input-group">
      <span class="input-group-addon">     
          <input type="radio" name='url' value='defoult' checked="checked">     
      </span>
                <input id="prependedcheckbox" class="form-control" type="text" readonly
                       value="http://avatarbugs.com/posts/?p=123">
            </div>

        </div>
    </div>

    <!-- Prepended checkbox -->
    <div class="form-group">
        <label class="col-md-4 control-label" for="day-name">Day and name</label>
        <div class="col-md-6">
            <div class="input-group">
      <span class="input-group-addon">     
          <input type="radio" value='dayName' name='url'>
      </span>
                <input id="day-name" class="form-control" type="text" readonly
                       value="http://avatarbugs.com/2016/02/25/my-post">
            </div>

        </div>
    </div>

    <!-- Prepended checkbox -->
    <div class="form-group">
        <label class="col-md-4 control-label" for="prependedcheckbox">Post name</label>
        <div class="col-md-6">
            <div class="input-group">
      <span class="input-group-addon">     
          <input type="radio" value='postName' name='url'>
      </span>
                <input id="prependedcheckbox" class="form-control" type="text" readonly
                       value="http://avatarbugs.com/my-post">
            </div>

        </div>
    </div>

    <!-- Prepended checkbox -->
    <div class="form-group">
        <label class="col-md-4 control-label" for="prependedcheckbox">Numeric</label>
        <div class="col-md-6">
            <div class="input-group">
      <span class="input-group-addon">     
          <input type="radio" value='numeric' name='url'>     
      </span>
                <input id="prependedcheckbox" class="form-control" type="text" readonly
                       value="http://avatarbugs.com/posts/123">
            </div>

        </div>
    </div>

    <!-- Prepended checkbox -->
    <div class="form-group">
        <label class="col-md-4 control-label" for="prependedcheckbox">Custom</label>
        <div class="col-md-6">
            <div class="input-group">
      <span class="input-group-addon">     
          <input type="radio" value='custom' name='url'>     
      </span>
                <input id="prependedcheckbox" class="form-control" type="text" readonly value="http://avatarbugs.com/">
            </div>

        </div>
    </div>

    <!-- Text input-->
    <div class="form-group">
        <label class="col-md-4 control-label" for="custom"></label>
        <div class="col-md-4">
            <input id="custom" name="custom" type="text" placeholder="/%postnme%/" class="form-control input-md">

        </div>
    </div>
    <!-- Button -->
    <div class="form-group">
        <label class="col-md-4 control-label" for="singlebutton"></label>
        <div class="col-md-4">
            <button id="singlebutton" class="btn btn-success">Save</button>
        </div>
    </div>

</fieldset>

