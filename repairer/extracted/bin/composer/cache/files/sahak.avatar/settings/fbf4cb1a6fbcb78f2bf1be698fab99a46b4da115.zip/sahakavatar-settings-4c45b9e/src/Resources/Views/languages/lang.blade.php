@extends('cms::layouts.mTabs',['index'=>'settings'])
<!-- Nav tabs -->
@section('tab')
    language
@stop