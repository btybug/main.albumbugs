@extends('layouts.admin')
@section('content')

    Shotcode

@stop
