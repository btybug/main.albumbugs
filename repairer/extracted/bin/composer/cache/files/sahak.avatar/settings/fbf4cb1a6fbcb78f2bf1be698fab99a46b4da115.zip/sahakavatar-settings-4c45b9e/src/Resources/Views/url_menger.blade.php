@extends('cms::layouts.mTabs',['index'=>'settings'])
@section('tab')
    URL menger
@stop

