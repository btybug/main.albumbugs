<div class="menuBuilder containerBuilderPreview">

        <section class="container-fluid" >
                <div class="row " id="builderContain">
                        <div class="col-xs-12 col-sm-6 previewAray">
                                <div class="classnamedetail">
                                <div class="row firstchild form-horizontal">
                                        <div class="col-xs-12 ">
                                                <div class="form-group p-b-0 m-b-0 uplaod-style">
                                                        <label class="col-lg-3 col-xs-12 m-t-5" for="fieldsType"><span class="class-style-icon"></span> Class Style</label>
                                                        <div class="col-lg-5 col-xs-6">
                                                                <div class="btn-group dropdown-button" role="group">
                                                                        <button type="button" data-toggle="collapse" data-target="#gradient-datalist" class="btn btn-block class-style-menu"><span class="filter-option pull-left">Default</span>&nbsp;<span class="caret"></span></button>
                                                                </div>
                                                        </div>
                                                        
                                                        <div class="col-lg-4 col-xs-6">
                                                                <button type="button" class=" btn uploadButton ">Upload Style</button>
                                                                <a href="" type="button" class=" btn uploadButton" data-download="css" download="text.css"><i class="glyphicon glyphicon-save"></i></a>
                                                        </div>
                                                </div>
                                        </div>
                                </div>
                                        
                                </div>
                                
                                <!--<div class="miniheight">

                    <div class="" data-role="classview">Lorem ipsum dolor sit amet, </div>
                </div>--> 
                                <!--  Preview Section -->
                                <div data-preview="container" data-print="demehtml"> 
                                        <!--  Apply css class  -->
                                        <div class="previewCol">
                                                <div class="" data-preview="studio" data-role="classview">Container</div>
                                        </div>
                                </div>
                                <textarea name="json_data" class="form-control hide" data-export="json" style="margin-top:10px">{!! $data_edit['jsonData'] or '{"border":{},"class":"classname","savedcss":".classname{background:radial-gradient(ellipse farthest-corner at 84% 72%, rgba(255,0,0,1) 2.38%, rgba(22,1,1,1) 87.43% ); }.classname:hover, .classname.hover{background:radial-gradient(ellipse farthest-corner at 84% 72%, rgba(255,0,231,1) 2.38%, rgba(22,1,1,1) 87.43% ); }.classname:focus, .classname.selected, .classname:active{background:radial-gradient(ellipse farthest-corner at 84% 72%, rgba(0,44,252,1) 2.38%, rgba(22,1,1,1) 87.43% ); }","classname":".classname","css":{"background":"radial-gradient(ellipse farthest-corner at 84% 72%, rgba(255,0,0,1) 2.38%, rgba(22,1,1,1) 87.43% )"},"hover":{"background":"radial-gradient(ellipse farthest-corner at 84% 72%, rgba(255,0,231,1) 2.38%, rgba(22,1,1,1) 87.43% )"},"selected":{"background":"radial-gradient(ellipse farthest-corner at 84% 72%, rgba(0,44,252,1) 2.38%, rgba(22,1,1,1) 87.43% )"},"tabs":{"hover":false,"selected":false,"css":true}}' !!}</textarea>
                                <textarea name="json_importdata" class="form-control hide" data-export="importjson"></textarea>
                                <textarea name="less_data" class="form-control m-t-40" data-export="css"></textarea>
                        </div>
                        <div class="col-xs-12 col-sm-6 formoptions containerBuilderEditor">
                                <ul class="stepNav nav-justified list-unstyled tabStepnav clearfix m-t-10 hide" data-tabnav="button">
                                        <li class="active"><a href="#" title="Step1" data-rolecss="css" class="clearfix col-xs-12">
                                                  <span class="col-xs-6 text-right p-r-0">Default</span> <span class="col-xs-6 text-left">
                                                        <label class="switch switch-flat switch-button m-b-0">
                                                                <input class="switch-input" type="checkbox" data-tabactive="css" />
                                                                <span class="switch-label" data-on="On" data-off="Off"></span> <span class="switch-handle active-grey"></span> </label>
                                                        </span> 
                                        </a></li>
                                        <li> <a href="#" title="Step1" data-rolecss="hover" class="clearfix col-xs-12"> <span class="col-xs-6 text-right p-r-0">Hover</span> <span class="col-xs-6 text-left">
                                                        <label class="switch switch-flat switch-button m-b-0">
                                                                <input class="switch-input" type="checkbox" data-tabactive="hover" />
                                                                <span class="switch-label" data-on="On" data-off="Off"></span> <span class="switch-handle active-grey"></span> </label>
                                                        </span> </a> </li>
                                        <li> <a href="#" title="Step1" data-rolecss="selected" class="clearfix col-xs-12"> <span class="col-xs-6 text-right p-r-0">Selected</span> <span class="col-xs-6 text-left">
                                                        <label class="switch switch-flat switch-button m-b-0">
                                                                <input class="switch-input" type="checkbox" data-tabactive="selected"/>
                                                                <span class="switch-label" data-on="On" data-off="Off"></span> <span class="switch-handle active-grey"></span> </label>
                                                        </span> </a> </li>
                                </ul>
                                
                                
                                <div class="gradient-data">
                                        <div class="collapse gradient-datalist" id="gradient-datalist">
                                                <div class="row">
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data1"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img2.png" alt=""></a> </div>
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data2"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img3.png" alt=""></a> </div>
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data3"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img4.png" alt=""></a> </div>
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data4"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img5.png" alt=""></a> </div>
                                                </div>
                                                <div class="row">
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data1"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img2.png" alt=""></a> </div>
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data2"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img3.png" alt=""></a> </div>
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data3"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img4.png" alt=""></a> </div>
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data4"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img5.png" alt=""></a> </div>
                                                </div>
                                                <div class="row">
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data1"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img2.png" alt=""></a> </div>
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data2"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img3.png" alt=""></a> </div>
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data3"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img4.png" alt=""></a> </div>
                                                        <div class="col-md-3 col-xs-6"> <a href="#" data-loadnew="data4"><img src="/appdata/app/Modules/Studio/Resources/Views/classes/container/img/gradient-sample-img5.png" alt=""></a> </div>
                                                </div>
                                        </div>
                                </div>
                                        
                                <!-- new style for container studio --> 
                                
                                <div class="row formrow form-horizontal">
                                        <div class="col-xs-12 studio-collapse-header p-t-10 p-b-5"> <span class=" pull-left"> <a data-toggle="collapse" href="#collapsecontainercoreclasses" class="iconstudio viewicon m-r-5" data-viewpopup="container"> <i class="fa fa-angle-down" aria-hidden="true"></i> </a> Core classes </span>   <span class=" m-l-10 pull-left">
                                                <label class="switch switch-flat switch-button">
                                                        <input class="switch-input" type="checkbox" data-switch="collapsecontainercoreclasses" data-cssexist="height"/>
                                                        <span class="switch-label" data-on="On" data-off="Off"></span> <span class="switch-handle "></span> </label>
                                                </span>  <a href="#" class="iconstudio addicon m-r-5 pull-right" ><i class="fa fa-power-off f-s-20" aria-hidden="true"></i></a>  </div>
                                                
                                        
                                                
                                        <div class="col-xs-12 studio-collapse-toobar collapse in " id="collapsecontainercoreclasses">
                                                <div class="p-10">
                                                
                                                       
                                                        <div class="row p-b-5 p-t-10"  >
                                                                <label class="col-xs-3  p-r-0 m-t-5" >display</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <select class="form-control customselect spacing-type" data-css="display" data-default="block" data-selector="display" data-style="class-style-menu">
                                                                                <option value="block">block</option>
                                                                                <option value="compact">compact</option>
                                                                                <option value="inherit">inherit</option>
                                                                                <option value="flex">flex</option>
                                                                                <option value="inline">inline</option>
                                                                                <option value="inline-block">inline-block</option>
                                                                                <option value="inline-table">inline-table</option>
                                                                                <option value="inline-flex">inline-flex</option>
                                                                                <option value="list-item marker">list-item marker</option>
                                                                                <option value="none">none</option>
                                                                                <option value="run-in">run-in</option>
                                                                                <option value="table">table</option>
                                                                                <option value="table-caption">table-caption</option>
                                                                                <option value="table-cell">table-cell</option>
                                                                                <option value="table-column">table-column</option>
                                                                                <option value="table-column-group">table-column-group</option>
                                                                                <option value="table-footer-group">table-footer-group</option>
                                                                                <option value="table-header-group">table-header-group</option>
                                                                                <option value="table-row">table-row</option>
                                                                        </select>
                                                                </div>
                                                                <label class="col-xs-3  p-r-0 m-t-5" data-showcontainer="settingFloat">float</label>
                                                                <div class="col-xs-3 p-l-0" data-showcontainer="settingFloat">
                                                                        <select class="form-control customselect spacing-type" data-css="float" data-default="none"  data-selector="float" data-style="class-style-menu">
                                                                                <option value="none">none</option>
                                                                                <option value="left">left</option>
                                                                                <option value="right">right</option>
                                                                        </select>
                                                                </div>
                                                        </div>
                                                        <div class="row p-b-5 p-t-10">
                                                                <label class="col-xs-3  p-r-0 m-t-5" >position</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <select class="form-control customselect spacing-type" data-css="position" data-default="static" data-selector="position" data-style="class-style-menu">
                                                                                <option value="static">static</option>
                                                                                <option value="absolute">absolute</option>
                                                                                <option value="fixed">fixed</option>
                                                                                <option value="relative">relative</option>
                                                                                <option value="initial">initial</option>
                                                                                <option value="inherit">inherit</option>
                                                                        </select>
                                                                </div>
                                                                <label class="col-xs-3  p-r-0 m-t-5" >z-index</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <div class="spinner dual">
                                                                                <input type="text" value="auto" data-role="editcss" data-css="z-index" data-default="auto"  class="form-control spacing-value">
                                                                                <select class="form-control spacing-type" data-default="auto">
                                                                                        <option value="auto">auto</option>
                                                                                        <option value="">-</option>
                                                                                </select>
                                                                                <div class="input-group-btn-vertical">
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                        <div class="collapse" data-showcontainer="positionsetting">
                                                        
                                                        <div class="row p-b-5 p-t-10">
                                                                <label class="col-xs-3  p-r-0 m-t-5" >Left</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <div class="spinner dual">
                                                                                <input type="text" value="auto" data-role="editcss" data-css="left" data-default="auto"  class="form-control spacing-value">
                                                                                <select class="form-control spacing-type" data-default="auto">
                                                                                        <option value="auto">auto</option>
                                                                                        <option value="px">px</option>
                                                                                        <option value="em">em</option>
                                                                                        <option value="%">%</option>
                                                                                </select>
                                                                                <div class="input-group-btn-vertical">
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <label class="col-xs-3  p-r-0 m-t-5" >Top</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <div class="spinner dual">
                                                                                <input type="text" value="auto" data-role="editcss" data-css="top" data-default="auto"  class="form-control spacing-value">
                                                                                <select class="form-control spacing-type" data-default="auto">
                                                                                        <option value="auto">auto</option>
                                                                                        <option value="px">px</option>
                                                                                        <option value="em">em</option>
                                                                                        <option value="%">%</option>
                                                                                </select>
                                                                                <div class="input-group-btn-vertical">
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                        
                                                        <div class="row p-b-5 p-t-10">
                                                                <label class="col-xs-3  p-r-0 m-t-5" >Right</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <div class="spinner dual">
                                                                                <input type="text" value="auto" data-role="editcss" data-css="right" data-default="auto"  class="form-control spacing-value">
                                                                                <select class="form-control spacing-type" data-default="auto">
                                                                                        <option value="auto">auto</option>
                                                                                        <option value="px">px</option>
                                                                                        <option value="em">em</option>
                                                                                        <option value="%">%</option>
                                                                                </select>
                                                                                <div class="input-group-btn-vertical">
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <label class="col-xs-3  p-r-0 m-t-5" >Bottom</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <div class="spinner dual">
                                                                                <input type="text" value="auto" data-role="editcss" data-css="bottom" data-default="auto"  class="form-control spacing-value">
                                                                                <select class="form-control spacing-type" data-default="auto">
                                                                                        <option value="auto">auto</option>
                                                                                        <option value="px">px</option>
                                                                                        <option value="em">em</option>
                                                                                        <option value="%">%</option>
                                                                                </select>
                                                                                <div class="input-group-btn-vertical">
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="row p-b-5 p-t-10">
                                                                <label class="col-xs-3  p-r-0 m-t-5" >box-sizing</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <select class="form-control customselect spacing-type" data-css="box-sizing" data-default="border-box" data-selector="box-sizing" data-style="class-style-menu">
                                                                                <option value="content-box">content-box</option>
                                                                                <option value="border-box">border-box</option>
                                                                                <option value="initial">initial</option>
                                                                                <option value="inherit">inherit</option>
                                                                        </select>
                                                                </div>
                                                                <label class="col-xs-3  p-r-0 m-t-5" >cursor</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <select class="form-control customselect spacing-type" data-css="cursor"  data-default="pointer" data-selector="cursor" data-style="class-style-menu">
                                                                                <option value="alias">alias</option>
                                                                                <option value="all-scroll">all-scroll</option>
                                                                                <option value="auto">auto</option>
                                                                                <option value="cell">cell</option>
                                                                                <option value="context-menu">context-menu</option>
                                                                                <option value="col-resize">col-resize</option>
                                                                                <option value="copy">copy</option>
                                                                                <option value="crosshair">crosshair</option>
                                                                                <option value="default">default</option>
                                                                                <option value="e-resize">e-resize</option>
                                                                                <option value="ew-resize">ew-resize</option>
                                                                                <option value="grab">grab</option>
                                                                                <option value="grabbing">grabbing</option>
                                                                                <option value="help">help</option>
                                                                                <option value="move">move</option>
                                                                                <option value="n-resize">n-resize</option>
                                                                                <option value="ne-resize">ne-resize</option>
                                                                                <option value="nesw-resize">nesw-resize</option>
                                                                                <option value="ns-resize">ns-resize</option>
                                                                                <option value="nw-resize">nw-resize</option>
                                                                                <option value="nwse-resize">nwse-resize</option>
                                                                                <option value="no-drop">no-drop</option>
                                                                                <option value="none">none</option>
                                                                                <option value="not-allowed">not-allowed</option>
                                                                                <option value="pointer">pointer</option>
                                                                                <option value="progress">progress</option>
                                                                                <option value="row-resize">row-resize</option>
                                                                                <option value="s-resize">s-resize</option>
                                                                                <option value="se-resize">se-resize</option>
                                                                                <option value="sw-resize">sw-resize</option>
                                                                                <option value="text">text</option>
                                                                                <option value="vertical-text">vertical-text</option>
                                                                                <option value="w-resize">w-resize</option>
                                                                                <option value="wait">wait</option>
                                                                                <option value="zoom-in">zoom-in</option>
                                                                                <option value="zoom-out">zoom-out</option>
                                                                                <option value="initial">initial</option>
                                                                                <option value="inherit">inherit</option>
                                                                        </select>
                                                                </div>
                                                        </div>
                                                        <div class="row p-b-5 p-t-10">
                                                                <label class="col-xs-3  p-r-0 m-t-5" >Overflow</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <select class="form-control customselect" data-css="overflow" data-default="inherit" data-selector="overflow"  data-style="class-style-menu">
                                                                                <option value="auto" selected="">auto</option>
                                                                                <option value="hidden">hidden</option>
                                                                                <option value="visible">visible</option>
                                                                                <option value="scroll">scroll</option>
                                                                                <option value="inherit">inherit</option>
                                                                        </select>
                                                                </div>
                                                                <label class="col-xs-3  p-r-0 m-t-5" >opacity</label>
                                                                <div class="col-xs-3 p-l-0">
                                                                        <div class="form-group">
                                                                                <div class="opacitySlider clearfix">
                                                                                        <div class="horzSlider settingSlider" data-css="opacity" data-default="auto" data-css-after="" data-slide-min="0" data-slide-max="1" data-slide-step="0.1" data-slide-val="1"></div>
                                                                                        <input type="text" value="1" id="opacityValue" data-rolecolor="opacity"  class="form-control">
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                </div>
                                        </div>
                                </div>
                                 <!-- Container Highet -->
                                <div class="row formrow form-horizontal">
                                        <div class="col-xs-12 studio-collapse-header p-t-10 p-b-5"> <span class=" pull-left"> <a data-toggle="collapse" href="#collapsecontainerHeight" class="iconstudio viewicon m-r-5" data-viewpopup="container"> <i class="fa fa-angle-down" aria-hidden="true"></i> </a> Container </span>   <span class=" m-l-10 pull-left">
                                                <label class="switch switch-flat switch-button">
                                                        <input class="switch-input" type="checkbox" data-switch="collapsecontainerHeight" data-cssexist="height"/>
                                                        <span class="switch-label" data-on="On" data-off="Off"></span> <span class="switch-handle "></span> </label>
                                                </span>  <a href="#" class="iconstudio addicon m-r-5 pull-right" ><i class="fa fa-power-off f-s-20" aria-hidden="true"></i></a>  <button class="pull-right m-r-5 btn  uploadButton" data-toggle="collapse" data-target="[data-showcontainer='containerAsset']"> Browser Asset</button ></div>
                                                
                                        
                                                
                                        <div class="col-xs-12 studio-collapse-toobar collapse in " id="collapsecontainerHeight">
                                                <div class="p-10">
                                                
                                                      
                                                        <div data-collapsegroup="height">
                                                                <div class="row">
                                                                        <label class="col-xs-3  p-r-0 m-t-5" >Container height</label>
                                                                        <div class="col-xs-9">
                                                                                <div class="radio-inline customelement">
                                                                                        <input type="radio" name="content-height" id="heightauto" checked value="auto" data-csstype="height" data-getcontainer="heightauto">
                                                                                        <label for="heightauto">Auto</label>
                                                                                </div>
                                                                                <div class="radio-inline customelement customelementInherit">
                                                                                        <input type="radio" name="content-height" id="heightsame" value="same" data-csstype="height" data-getcontainer="heightFixed">
                                                                                        <label  for="heightsame">Fixed</label>
                                                                                </div>
                                                                                <div class="radio-inline customelement">
                                                                                        <input type="radio" name="content-height" id="heightcustomize" value="customize" data-csstype="height" data-getcontainer="heightcustomize">
                                                                                        <label for="heightcustomize">Range</label>
                                                                                </div>
                                                                                
                                                                                
                                                                        </div>
                                                                </div>
                                                                <div class="collapse" data-showcontainer="heightFixed">
                                                                        <div class="row p-b-5 p-t-10"  >
                                                                                <label class="col-xs-3  p-r-0 m-t-5" >Height</label>
                                                                                <div class="col-xs-3 p-l-0">
                                                                                        <div class="spinner dual">
                                                                                                <input type="text" value="500" data-role="editcss" data-min='0' data-css="height" data-default="500"  class="form-control spacing-value">
                                                                                                <select class="form-control spacing-type" data-default="px">
                                                                                                        <option value="px">px</option>
                                                                                                        <option value="em">em</option>
                                                                                                        <option value="%">%</option>
                                                                                                </select>
                                                                                                <div class="input-group-btn-vertical">
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                                </div>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <div class="collapse" data-showcontainer="heightcustomize">
                                                                        <div class="row p-b-5 p-t-10"  >
                                                                                <label class="col-xs-3  p-r-0 m-t-5" >min-height</label>
                                                                                <div class="col-xs-3 p-l-0">
                                                                                        <div class="spinner dual">
                                                                                                <input type="text" value="50" data-role="editcss" data-min='0' data-css="min-height" data-default="50"  class="form-control spacing-value">
                                                                                                <select class="form-control spacing-type" data-default="px">
                                                                                                        <option value="px">px</option>
                                                                                                        <option value="em">em</option>
                                                                                                        <option value="%">%</option>
                                                                                                </select>
                                                                                                <div class="input-group-btn-vertical">
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                                </div>
                                                                                        </div>
                                                                                </div>
                                                                                <label class="col-xs-3  p-r-0 m-t-5" >Max Height</label>
                                                                                <div class="col-xs-3 p-l-0">
                                                                                        <div class="spinner dual">
                                                                                                <input type="text" value="500" data-min='0' data-role="editcss" data-css="max-height" data-default="500"  class="form-control spacing-value">
                                                                                                <select class="form-control spacing-type" data-default="px">
                                                                                                        <option value="px">px</option>
                                                                                                        <option value="em">em</option>
                                                                                                        <option value="%">%</option>
                                                                                                </select>
                                                                                                <div class="input-group-btn-vertical">
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                                </div>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                        <div data-collapsegroup="width">
                                                                <div class="row">
                                                                        <label class="col-xs-3  p-r-0 m-t-5" >Container width</label>
                                                                        <div class="col-xs-9">
                                                                                <div class="radio-inline customelement">
                                                                                        <input type="radio" name="content-width" id="widthauto" checked value="auto" data-csstype="width" data-getcontainer="widthauto">
                                                                                        <label for="widthauto">Auto</label>
                                                                                </div>
                                                                                <div class="radio-inline customelement customelementInherit">
                                                                                        <input type="radio" name="content-width" id="widthsame" value="same" data-csstype="width" data-getcontainer="widthFixed">
                                                                                        <label  for="widthsame">Fixed</label>
                                                                                </div>
                                                                                <div class="radio-inline customelement">
                                                                                        <input type="radio" name="content-width" id="widthcustomize" value="customize" data-csstype="width" data-getcontainer="widthcustomize">
                                                                                        <label for="widthcustomize">Range</label>
                                                                                </div>
                                                                                
                                                                                
                                                                        </div>
                                                                </div>
                                                                <div class="collapse" data-showcontainer="widthFixed">
                                                                        <div class="row p-b-5 p-t-10"  >
                                                                                <label class="col-xs-3  p-r-0 m-t-5" >Width</label>
                                                                                <div class="col-xs-3 p-l-0">
                                                                                        <div class="spinner dual">
                                                                                                <input type="text" value="500" data-role="editcss" data-min='0' data-css="width" data-default="500"  class="form-control spacing-value">
                                                                                                <select class="form-control spacing-type" data-default="px">
                                                                                                        <option value="px">px</option>
                                                                                                        <option value="em">em</option>
                                                                                                        <option value="%">%</option>
                                                                                                </select>
                                                                                                <div class="input-group-btn-vertical">
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                                </div>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <div class="collapse" data-showcontainer="widthcustomize">
                                                                        <div class="row p-b-5 p-t-10"  >
                                                                                <label class="col-xs-3  p-r-0 m-t-5" >min-width</label>
                                                                                <div class="col-xs-3 p-l-0">
                                                                                        <div class="spinner dual">
                                                                                                <input type="text" value="50" data-role="editcss" data-min='0' data-css="min-width" data-default="50"  class="form-control spacing-value">
                                                                                                <select class="form-control spacing-type" data-default="px">
                                                                                                        <option value="px">px</option>
                                                                                                        <option value="em">em</option>
                                                                                                        <option value="%">%</option>
                                                                                                </select>
                                                                                                <div class="input-group-btn-vertical">
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                                </div>
                                                                                        </div>
                                                                                </div>
                                                                                <label class="col-xs-3  p-r-0 m-t-5" >Max width</label>
                                                                                <div class="col-xs-3 p-l-0">
                                                                                        <div class="spinner dual">
                                                                                                <input type="text" value="500" data-min='0' data-role="editcss" data-css="max-width" data-default="500"  class="form-control spacing-value">
                                                                                                <select class="form-control spacing-type" data-default="px">
                                                                                                        <option value="px">px</option>
                                                                                                        <option value="em">em</option>
                                                                                                        <option value="%">%</option>
                                                                                                </select>
                                                                                                <div class="input-group-btn-vertical">
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                        <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                                </div>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                     
                                                </div>
                                        </div>
                                </div>
                                
                                <!-- Background -->
                                
                                <div class="row formrow form-horizontal">
                                        <div class="col-xs-12 studio-collapse-header p-t-10 p-b-5"> <span class=" pull-left"> <a data-toggle="collapse" href="#collapseBackground" class="iconstudio viewicon m-r-5" data-viewpopup="container"> <i class="fa fa-angle-down" aria-hidden="true"></i> </a> Background </span> <span class=" m-l-10 pull-left">
                                                <label class="switch switch-flat switch-button">
                                                        <input class="switch-input" type="checkbox" data-switch="collapseBackground" data-cssexist="background"/>
                                                        <span class="switch-label" data-on="On" data-off="Off"></span> <span class="switch-handle "></span> </label>
                                                </span> <a href="#" class="iconstudio addicon m-r-5 pull-right" ><i class="fa fa-power-off f-s-20" aria-hidden="true"></i></a> </div>
                                        <div class="col-xs-12 studio-collapse-toobar collapse in " id="collapseBackground">
                                                  <input type="text" class="form-control hide" id="" data-val="radial-gradient(ellipse farthest-corner at 84% 72%, rgba(255,0,0,1) 2.38%, rgba(22,1,1,1) 87.43% )" value="radial-gradient(ellipse farthest-corner at 84% 72%, rgba(255,0,0,1) 2.38%, rgba(22,1,1,1) 87.43% )" name="" data-subcss="color" data-css="background">
                                                  <div class="insetColorStodio"></div>
                                        </div>
                                </div>
                                
                                <!-- Border and Radius -->
                                
                                <div class="row formrow form-horizontal">
                                        <div class="col-xs-12 studio-collapse-header p-t-10 p-b-5"> <span class="pull-left"> <a data-toggle="collapse" href="#collapseBorderRadius" class="iconstudio viewicon  m-r-5" data-viewpopup="container"> <i class="fa fa-angle-down" aria-hidden="true"></i> </a> Border and Radius </span> <span class=" m-l-10 pull-left">
                                                <label class="switch switch-flat switch-button">
                                                        <input class="switch-input" data-switch="collapseBorderRadius" data-cssexist="border-radius" type="checkbox"/>
                                                        <span class="switch-label" data-on="On" data-off="Off"></span> <span class="switch-handle "></span> </label>
                                                </span> <a href="#" class="iconstudio addicon m-r-5 pull-right" ><i class="fa fa-power-off f-s-20" aria-hidden="true"></i></a> </div>
                                        <div class="col-xs-12 studio-collapse-toobar collapse in" id="collapseBorderRadius">
                                                <div class="borderRadius">
                                                <div class="row">
                                                        <div class="col-xs-12 col-md-12  col-lg-6 p-t-10 p-b-20 border-section">
                                                                <div class="col-xs-12">
                                                                        <div class="radio-inline customelement">
                                                                                <input type="radio" name="bordertype" id="bordersame" value="same" data-csstype="border" data-getcontainer="">
                                                                                <label  for="bordersame">Same Border</label>
                                                                        </div>
                                                                        <div class="radio-inline customelement">
                                                                                <input type="radio" name="bordertype" id="bordercustomize" checked value="customize" data-csstype="border" data-getcontainer="bordercustomize">
                                                                                <label for="bordercustomize">Customize</label>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12  m-t-5" data-role="borderGroup" data-roletype="top">
                                                                        <label class="col-xs-3  p-r-0 m-t-5" data-lable-title="top">Top</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner">
                                                                                        <input type="text" value="1" data-css="border-width" data-html="top" data-multycss="border" id="AngleInput" class="form-control">
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                        <div class="col-xs-2 p-l-0"> <span class="input-group color-picker input-color input-color-inblock" data-html="top" data-multycss="border">
                                                                                <input type="text" class="form-control hide" id="" value="#000" name="" data-css="border-color" data-html="top" data-multycss="border" >
                                                                                <span class="input-group-addon"><i></i></span> </span> </div>
                                                                        <div class="col-xs-4 p-l-0">
                                                                                <select class="form-control customselect" data-css="border-style" data-html="top" data-multycss="border"  data-selector="border"  data-style="class-style-menu">
                                                                                        <option value="solid" selected="">Solid</option>
                                                                                        <option value="dashed">Dashed</option>
                                                                                        <option value="dotted">Dotted</option>
                                                                                        <option value="double">Double</option>
                                                                                        <option value="groove">Groove</option>
                                                                                        <option value="hidden">Hidden</option>
                                                                                        <option value="inset">Inset</option>
                                                                                        <option value="none">None</option>
                                                                                        <option value="outset">Outset</option>
                                                                                        <option value="ridge">Ridge</option>
                                                                                </select>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12  m-t-5" data-role="borderGroup" data-roletype="right">
                                                                        <label class="col-xs-3  p-r-0 m-t-5">Right</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner">
                                                                                        <input type="text" value="1" data-css="border-width" data-html="right" data-multycss="border" id="AngleInput" class="form-control">
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                        <div class="col-xs-2 p-l-0"> <span class="input-group color-picker input-color input-color-inblock" data-html="right" data-multycss="border">
                                                                                <input type="text" class="form-control hide" id=""  name="" data-css="border-color" data-html="right" data-multycss="border" >
                                                                                <span class="input-group-addon"><i></i></span> </span> </div>
                                                                        <div class="col-xs-4 p-l-0">
                                                                                <select class="form-control customselect" data-css="border-style" data-html="right" data-multycss="border"  data-selector="border"  data-style="class-style-menu">
                                                                                        <option value="solid" selected="">Solid</option>
                                                                                        <option value="dashed">Dashed</option>
                                                                                        <option value="dotted">Dotted</option>
                                                                                        <option value="double">Double</option>
                                                                                        <option value="groove">Groove</option>
                                                                                        <option value="hidden">Hidden</option>
                                                                                        <option value="inset">Inset</option>
                                                                                        <option value="none">None</option>
                                                                                        <option value="outset">Outset</option>
                                                                                        <option value="ridge">Ridge</option>
                                                                                </select>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12  m-t-5" data-role="borderGroup" data-roletype="bottom">
                                                                        <label class="col-xs-3  p-r-0 m-t-5">Bottom</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner">
                                                                                        <input type="text" value="1" data-css="border-width" data-html="bottom" data-multycss="border" id="AngleInput" class="form-control">
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                        <div class="col-xs-2 p-l-0"> <span class="input-group color-picker input-color input-color-inblock" data-html="bottom" data-multycss="border">
                                                                                <input type="text" class="form-control hide" id="" value="#000" name="" data-css="border-color" data-html="bottom" data-multycss="border" >
                                                                                <span class="input-group-addon"><i></i></span> </span> </div>
                                                                        <div class="col-xs-4 p-l-0">
                                                                                <select class="form-control customselect" data-css="border-style" data-html="bottom" data-multycss="border"  data-selector="border"  data-style="class-style-menu">
                                                                                        <option value="solid" selected="">Solid</option>
                                                                                        <option value="dashed">Dashed</option>
                                                                                        <option value="dotted">Dotted</option>
                                                                                        <option value="double">Double</option>
                                                                                        <option value="groove">Groove</option>
                                                                                        <option value="hidden">Hidden</option>
                                                                                        <option value="inset">Inset</option>
                                                                                        <option value="none">None</option>
                                                                                        <option value="outset">Outset</option>
                                                                                        <option value="ridge">Ridge</option>
                                                                                </select>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12  m-t-5" data-role="borderGroup" data-roletype="left">
                                                                        <label class="col-xs-3  p-r-0 m-t-5">left</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner">
                                                                                        <input type="text" value="1" data-css="border-width" data-html="left" data-multycss="border" class="form-control">
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                        <div class="col-xs-2 p-l-0"> <span class="input-group color-picker input-color input-color-inblock" data-html="left" data-multycss="border">
                                                                                <input type="text" class="form-control hide" id="" value="#000" name="" data-css="border-color" data-html="left" data-multycss="border" >
                                                                                <span class="input-group-addon"><i></i></span> </span> </div>
                                                                        <div class="col-xs-4 p-l-0">
                                                                                <select class="form-control customselect" data-css="border-style" data-html="left" data-multycss="border"  data-selector="border"  data-style="class-style-menu">
                                                                                        <option value="solid" selected="">Solid</option>
                                                                                        <option value="dashed">Dashed</option>
                                                                                        <option value="dotted">Dotted</option>
                                                                                        <option value="double">Double</option>
                                                                                        <option value="groove">Groove</option>
                                                                                        <option value="hidden">Hidden</option>
                                                                                        <option value="inset">Inset</option>
                                                                                        <option value="none">None</option>
                                                                                        <option value="outset">Outset</option>
                                                                                        <option value="ridge">Ridge</option>
                                                                                </select>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                        <div class="col-xs-12 col-md-12  col-lg-6  p-t-10 p-b-20  border-section">
                                                                <div class="col-xs-12">
                                                                        <div class="radio-inline customelement">
                                                                                <input type="radio" name="radiustype" id="radiussame" value="same" data-csstype="border-radius" data-getcontainer="">
                                                                                <label  for="radiussame">Same Radius</label>
                                                                        </div>
                                                                        <div class="radio-inline customelement">
                                                                                <input type="radio" name="radiustype" id="radiuscustomize" value="customize" data-csstype="border-radius" data-getcontainer="radiuscustomize" checked>
                                                                                <label for="radiuscustomize">Customize</label>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12  m-t-20">
                                                                        <div class="col-xs-3 p-l-0" data-role="border-radiusGroup" data-roletype="top">
                                                                                <div class="spinner">
                                                                                        <input type="text" value="03" data-html="top" data-multycss="borderRadius" data-css="border-radius" data-min='0' class="form-control">
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                        <div class="col-xs-3 " data-role="border-radiusGroup" data-roletype="top">
                                                                                <label class=" border-radius border-radius-top" for="top_border"></label>
                                                                        </div>
                                                                        <div class="col-xs-3 " data-role="border-radiusGroup" data-roletype="right">
                                                                                <label class=" border-radius  border-radius-right" for="top_border"></label>
                                                                        </div>
                                                                        <div class="col-xs-3 p-l-0" data-role="border-radiusGroup" data-roletype="right">
                                                                                <div class="spinner">
                                                                                        <input type="text" value="03" data-html="right" data-multycss="borderRadius" data-css="border-radius" data-min='0' class="form-control">
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12  m-t-20 ">
                                                                        <div class="col-xs-3 p-l-0" data-role="border-radiusGroup" data-roletype="left">
                                                                                <div class="spinner">
                                                                                        <input type="text" value="03" data-html="left" data-multycss="borderRadius" data-css="border-radius" data-min='0' class="form-control">
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                        <div class="col-xs-3 " data-role="border-radiusGroup" data-roletype="left">
                                                                                <label class="border-radius  border-radius-left" for="top_border"></label>
                                                                        </div>
                                                                        <div class="col-xs-3" data-role="border-radiusGroup" data-roletype="bottom">
                                                                                <label class=" border-radius  border-radius-bottom" for="top_border"></label>
                                                                        </div>
                                                                        <div class="col-xs-3 p-l-0"  data-role="border-radiusGroup" data-roletype="bottom">
                                                                                <div class="spinner">
                                                                                        <input type="text" value="03" data-html="bottom" data-multycss="borderRadius" data-min='0' data-css="border-radius" class="form-control">
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                </div>
                                                </div> 
                                        </div>
                                </div>
                                
                                <!-- Shadow -->
                                <div class="row formrow form-horizontal">
                                        <div class="col-xs-12 studio-collapse-header p-t-10"> <span class="pull-left"> <a data-toggle="collapse" href="#collapseShadow" class="iconstudio viewicon m-r-5" data-viewpopup="container"> <i class="fa fa-angle-down" aria-hidden="true"></i> </a> Shadow </span> <span class=" m-l-10 pull-left">
                                                <label class="switch switch-flat switch-button">
                                                        <input class="switch-input" data-switch="collapseShadow" data-cssexist="box-shadow" type="checkbox"/>
                                                        <span class="switch-label" data-on="On" data-off="Off"></span> <span class="switch-handle "></span> </label>
                                                </span> <a href="#" class="iconstudio addicon m-r-5 pull-right" ><i class="fa fa-power-off f-s-20" aria-hidden="true"></i></a> <a href="#" class="iconstudio viewicon m-r-5 pull-right" data-css="box-shadow" data-multycss="boxShadow" data-roletemplate="boxShadow"><i class="fa fa-plus" aria-hidden="true"></i></a> </div>
                                        <div class="col-xs-12 studio-collapse-toobar collapse in" data-insettemp="boxShadow" id="collapseShadow"> </div>
                                </div>
                                
                                <!-- Margin and Padding -->
                                
                                <div class="row formrow form-horizontal">
                                        <div class="col-xs-12 studio-collapse-header p-t-10 p-b-5"> <span class=" pull-left"> <a data-toggle="collapse" href="#collapseMarginPadding" class="iconstudio viewicon m-r-5" data-viewpopup="container"> <i class="fa fa-angle-down" aria-hidden="true"></i> </a> Margin and Padding </span> <a href="#" class="iconstudio addicon m-r-5 pull-right" ><i class="fa fa-power-off f-s-20" aria-hidden="true"></i></a> </div>
                                        <div class="col-xs-12 studio-collapse-toobar collapse in" id="collapseMarginPadding">
                                                <div class="row ">
                                                        <div class="col-xs-12 col-md-12  col-lg-6 p-t-10 p-b-20 border-section">
                                                                <div class="col-xs-12">
                                                                        <div class="radio-inline customelement">
                                                                                <input type="radio" name="margintype" id="marginsame" value="same" data-csstype="margin" data-getcontainer="">
                                                                                <label  for="marginsame">Same Margin</label>
                                                                        </div>
                                                                        <div class="radio-inline customelement">
                                                                                <input type="radio" name="margintype" id="margincustomize" checked value="customize" data-csstype="margin" data-getcontainer="bordercustomize">
                                                                                <label for="margincustomize">Customize</label>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12  m-t-5 " data-role="marginGroup" data-roletype="top">
                                                                        <label class="col-xs-3  p-r-0 m-t-5" data-lable-title="top">Top</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner dual">
                                                                                        <input type="text" value="auto" data-role="editcss" data-css="margin-top" data-same="margin" class="form-control spacing-value">
                                                                                        <select class="form-control spacing-type">
                                                                                            <option value="auto">auto</option>
                                                                                            <option value="px">px</option>
                                                                                             <option value="em">em</option>
                                                                                              <option value="%">%</option>
                                                                                        </select>
                                                                                       
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12 m-t-5" data-role="marginGroup" data-roletype="right">
                                                                        <label class="col-xs-3 p-r-0  m-t-5">Right</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner dual">
                                                                                        <input type="text" value="auto" data-role="editcss" data-css="margin-right" data-same="margin" class="form-control spacing-value">
                                                                                        <select class="form-control spacing-type">
                                                                                            <option value="auto">auto</option>
                                                                                            <option value="px">px</option>
                                                                                             <option value="em">em</option>
                                                                                              <option value="%">%</option>
                                                                                        </select>
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12 m-t-5" data-role="marginGroup" data-roletype="bottom">
                                                                        <label class="col-xs-3 p-r-0  m-t-5">Bottom</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner dual">
                                                                                        <input type="text" value="auto" data-role="editcss" data-css="margin-bottom" data-same="margin" class="form-control spacing-value">
                                                                                        <select class="form-control spacing-type">
                                                                                           <option value="auto">auto</option>
                                                                                            <option value="px">px</option>
                                                                                             <option value="em">em</option>
                                                                                              <option value="%">%</option>
                                                                                        </select>
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12 m-t-5" data-role="marginGroup" data-roletype="left">
                                                                        <label class="col-xs-3 p-r-0  m-t-5">Left</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner dual">
                                                                                        <input type="text" value="auto" data-role="editcss" data-css="margin-left" data-same="margin"  class="form-control spacing-value">
                                                                                        <select class="form-control spacing-type">
                                                                                            <option value="auto">auto</option>
                                                                                            <option value="px">px</option>
                                                                                             <option value="em">em</option>
                                                                                              <option value="%">%</option>
                                                                                        </select>
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                        <div class="col-xs-12 col-md-12  col-lg-6  p-t-10 p-b-20 ">
                                                                <div class="col-xs-12">
                                                                        <div class="radio-inline customelement">
                                                                                <input type="radio" name="paddingtype" id="paddingsame" value="same" data-csstype="padding" data-getcontainer="">
                                                                                <label  for="paddingsame">Same Padding</label>
                                                                        </div>
                                                                        <div class="radio-inline customelement">
                                                                                <input type="radio" name="paddingtype" id="paddingcustomize" checked value="customize" data-csstype="padding" data-getcontainer="radiuscustomize">
                                                                                <label for="paddingcustomize">Customize</label>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12  m-t-5" data-role="paddingGroup" data-roletype="top">
                                                                        <label class="col-xs-3  p-r-0 m-t-5" data-lable-title="top">Top</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner dual">
                                                                                        <input type="text" value="0" data-role="editcss" data-css="padding-top" data-same="padding" class="form-control spacing-value">
                                                                                        <select class="form-control spacing-type">
                                                                                            <option value="px">px</option>
                                                                                             <option value="em">em</option>
                                                                                              <option value="%">%</option>
                                                                                        </select>
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12 m-t-5" data-role="paddingGroup" data-roletype="right">
                                                                        <label class="col-xs-3 p-r-0  m-t-5" >Right</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner dual">
                                                                                        <input type="text" value="0"  data-role="editcss" data-css="padding-right" data-same="padding" class="form-control spacing-value">
                                                                                        <select class="form-control spacing-type">
                                                                                            <option value="px">px</option>
                                                                                             <option value="em">em</option>
                                                                                              <option value="%">%</option>
                                                                                        </select>
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12 m-t-5" data-role="paddingGroup" data-roletype="bottom">
                                                                        <label class="col-xs-3 p-r-0  m-t-5">Bottom </label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner dual">
                                                                                        <input type="text" value="0" data-role="editcss" data-css="padding-bottom" data-same="padding" class="form-control spacing-value">
                                                                                        <select class="form-control spacing-type">
                                                                                            <option value="px">px</option>
                                                                                             <option value="em">em</option>
                                                                                              <option value="%">%</option>
                                                                                        </select>
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xs-12 m-t-5" data-role="paddingGroup" data-roletype="left">
                                                                        <label class="col-xs-3 p-r-0  m-t-5">Left</label>
                                                                        <div class="col-xs-3 p-l-0">
                                                                                <div class="spinner dual">
                                                                                        <input type="text" value="0" data-role="editcss" data-css="padding-left" data-same="padding"  class="form-control spacing-value">
                                                                                        <select class="form-control spacing-type">
                                                                                            <option value="px">px</option>
                                                                                             <option value="em">em</option>
                                                                                              <option value="%">%</option>
                                                                                        </select>
                                                                                        <div class="input-group-btn-vertical">
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                </div>
                                        </div>
                                </div>
                                
                                <!-- end new style for container studio --> 
                                
                                <div class="disablelayout hide" data-activetab="suporter"></div>
                                
                        </div>
                </div>
        </section>
</div>
<script type="template" data-template="boxShadow">
  <div class="row textGroupRow" data-role="textGroup">
  <a href="#" class="iconstudio addicon m-r-5 removetextRow" data-mylticss="boxShadow" data-role="removeTextShedow"><i class="fa fa-times" aria-hidden="true"></i></a>
                            <div class="colRow">
                                    <div class="col-xs-6 col-md-6  col-lg-1  p-t-10 p-b-10 border-shadow-color ">
                                            <span class="input-group color-picker input-color input-color-inblock" data-multycss="boxShadow" data-shadowcolor="color">
                                                <input type="text" class="form-control hide" id="" value="#000" name="" data-multycss="boxShadow" data-html="color">
                                                <span class="input-group-addon"><i></i></span>
                                            </span>
                                           
                                    </div>
                                    
                                     <div class="col-xs-6 col-md-6  col-lg-2   p-t-10 p-b-10 border-shadow-offset-x">
                                                              <select data-selector="fontweight" data-style="btn-black " data-multycss="boxShadow" data-subcss="type" data-css="box-shadow" class="form-control customselect" >
                                            <option selected="" value="">Outer shadow</option>
                                            <option value="inset"> Inner shadow</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-xs-6 col-md-6  col-lg-2   p-t-10 p-b-10 border-shadow-offset-x">
                                        <label class="col-xs-5 p-l-0 m-t-5"> X</label>
                                        <div class="col-xs-6 p-l-0">
                                                <div class="spinner">
                                                        <input type="text" value="0" data-multycss="boxShadow" data-html="x" data-css="x" class="form-control">
                                                        <div class="input-group-btn-vertical">
                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                        </div>
                                                </div>
                                            
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-md-6  col-lg-2 p-t-10 p-b-10 border-shadow-offset-y">
                                        <label class="col-xs-5 p-l-0 m-t-5">Y</label>
                                        <div class="col-xs-6 p-l-0">
                                            <div class="spinner">
                                                    <input type="text" value="0" data-multycss="boxShadow" data-html="y" data-css="y"   class="form-control">
                                                    <div class="input-group-btn-vertical">
                                                            <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                            <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                    </div>
                                            </div>
                                         </div>   
                                    </div>
                            </div>
                            <div class="colRow">
                                     <div class="col-xs-6 col-md-6  col-lg-2 p-t-10 p-b-10 border-shadow-offset-y">
                                        <label class="col-xs-5 p-l-0 m-t-5">spread</label>
                                        <div class="col-xs-6 p-l-0">
                                            <div class="spinner">
                                                    <input type="text" value="0" data-multycss="boxShadow" data-html="spread" data-css="spread"   class="form-control">
                                                    <div class="input-group-btn-vertical">
                                                            <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                            <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                    </div>
                                            </div>
                                         </div>   
                                    </div>
                                    <div class="col-xs-6 col-md-6  col-lg-2  p-t-10 p-b-10 border-shadow-blur">
                                        <label class="col-xs-6 p-l-0 m-t-5" >Blur</label>
                                        <div class="col-xs-6 p-l-0">
                                            <div class="spinner">
                                                        <input type="text" value="0"data-multycss="boxShadow" data-html="blur" data-css="blur"   data-min="0" class="form-control">
                                                        <div class="input-group-btn-vertical">
                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                                                                <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                                                        </div>
                                                </div>
                                             </div> 
                                    </div>
                            </div>                                    
                        </div>
</script>

{!! HTML::style('/app/Modules/Studios/Resources/Views/Classes/container/css/container-studio.css?v=0.57') !!}
<style id="savedcss" data-role="savedcss">
</style>
@push('javascript') 
<script src="/app/Modules/Studios/Resources/Views/public/js/studio-plugin-new.js" type="text/javascript"></script> 
<script src="/app/Modules/Studios/Resources/Views/Classes/container/js/class-container-builder.js?v=3.40" type="text/javascript"></script> 
@endpush