{{--<div data-role="classview">--}}
    {{--<img src="/app/Modules/Resources/Resources/assets/img/layout-img.jpg" alt="Avatar">--}}
   {{--<div>--}}
       {{--<h4><b>John Doe</b></h4>--}}
       {{--<p>Architect & Engineer</p>--}}
   {{--</div>--}}
{{--</div>--}}
<div data-role="classview">
    <h1>My Page</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vestibulum, turpis quis convallis varius, metus ipsum tristique erat, in laoreet nisi velit vitae ipsum.</p>
    <div>
        <img src="/app/Modules/Resources/Resources/assets/img/layout-img.jpg">
    </div>
    <h2>Maecenas id lorem nec dolor sagittis lacinia</h2>
    <p>Etiam elementum pulvinar diam sit amet tincidunt. </p>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vestibulum, turpis quis convallis varius, metus ipsum tristique erat, in laoreet nisi velit vitae ipsum.</p>
    <div>
        <button type="button">Read more</button>
        <button type="button">Button</button>
    </div>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vestibulum, turpis quis convallis varius, metus ipsum tristique erat, in laoreet nisi velit vitae ipsum.</p>
    <ul>
        <li>Goofy</li>
        <li>Mickey</li>
        <li>Daisy</li>
        <li>Pluto</li>
    </ul>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vestibulum, turpis quis convallis varius, metus ipsum tristique erat, in laoreet nisi velit vitae ipsum.</p>
    <button type="button">Button</button>
</div>