<form data-role="classview">
   <div>
       <label for="exampleInputEmail1">Example text input</label>
       <input type="text" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Text">
   </div>
   <div>
       <label for="exampleSelect1">Example select</label>
       <select id="exampleSelect1">
           <option>Option 1</option>
           <option>Option 2</option>
           <option>Option 3</option>
           <option>Option 4</option>
           <option>Option 5</option>
       </select>
   </div>
   <div>
       <label for="exampleTextarea">Example textarea</label>
       <textarea id="exampleTextarea" rows="3"></textarea>
   </div>
   <div>
       <label for="exampleInputFile">File input</label>
       <input type="file" id="exampleInputFile" aria-describedby="fileHelp">
   </div>
       <div>
           <label>
               <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1">
               Option one is this and that&mdash;be sure to include why it's great
           </label>
       </div>
   <div>
       <label>
           <input type="checkbox">
           Check me out
       </label>
   </div>
   <button type="submit">Submit</button>
</form>