 <div data-role="classview">
   <button type="button">Left</button>
   <button type="button">Middle</button>
   <button type="button">Right</button>
</div>
