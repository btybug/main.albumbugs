<div data-role="classview">
   <div>
       <span id="basic-addon1">@</span>
       <input type="text" placeholder="Username" aria-describedby="basic-addon1">
   </div>
   <br>
   <div>
       <input type="text" placeholder="Recipient's username" aria-describedby="basic-addon2">
       <span id="basic-addon2">@example.com</span>
   </div>
   <br>
   <label for="basic-url">Your vanity URL</label>
   <div>
       <span id="basic-addon3">https://example.com/users/</span>
       <input type="text" id="basic-url" aria-describedby="basic-addon3">
   </div>
   <br>
   <div>
       <span>$</span>
       <input type="text" aria-label="Amount (to the nearest dollar)">
       <span>.00</span>
   </div>
   <br>
   <div>
       <span>$</span>
       <span>0.00</span>
       <input type="text" aria-label="Amount (to the nearest dollar)">
   </div>
</div>