<nav data-role="classview">
   {{--<button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">--}}
       {{--<span></span>--}}
   {{--</button>--}}
   {{--<a href="#">Navbar</a>--}}

<ul>
   <li><a href="#home">Home</a></li>
   <li><a href="#news">News</a></li>
   <li><a href="#contact">Contact</a></li>
   <li><a href="#about">About</a></li>
</ul>
</nav>