<div data-role="classview">
   <div>Panel heading without title</div>
   <div>
       Panel content
    </div>
</div>