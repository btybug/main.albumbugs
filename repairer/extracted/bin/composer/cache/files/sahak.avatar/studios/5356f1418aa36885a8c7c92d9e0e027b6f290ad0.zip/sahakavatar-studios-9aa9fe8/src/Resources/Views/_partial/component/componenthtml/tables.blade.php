<table data-role="classview">
   <thead>
   <tr>
       <th>Table head</th>
       <th>Table head</th>
       <th>Table head</th>
       <th>Table head</th>
       <th>Table head</th>
   </tr>
   </thead>
   <tbody>
   <tr>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
   </tr>
   <tr>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
   </tr>
   <tr>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
   </tr>
   <tr>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
   </tr>
   <tr>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
       <td>Table data</td>
   </tr>
   </tbody>
</table>