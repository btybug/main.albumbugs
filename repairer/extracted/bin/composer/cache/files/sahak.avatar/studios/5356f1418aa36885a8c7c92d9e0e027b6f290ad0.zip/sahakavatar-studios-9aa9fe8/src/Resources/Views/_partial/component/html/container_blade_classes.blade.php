  <div class="row formrow form-horizontal" data-opstudios="cssselector">
                    <div class="col-xs-12">
                        Edit  <span data-actviestduio="">Defult</span> View
                     </div>
                  </div>
                 <div data-previewcolumn="option">
                
                 <ul class="stepNav list-unstyled nav-justified tabStepnav clearfix m-t-10 " role="tablist" data-studitabs="opstudios">
                                        <li data-opstudios="basicclasses"><a  href="#basicstyles" aria-controls="basic_classes" role="tab" data-toggle="tab">Basic classes </a></li>
                                        <li data-opstudios="textcollection"><a  href="#textcollectionstyles" aria-controls="collectionstyles" role="tab" data-toggle="tab" >Text classes </a></li>
                                        <li data-opstudios="containercollections"><a  href="#containercollectionstyles" aria-controls="collectionstyles" role="tab" data-toggle="tab" >Container classes </a></li>
                                         <li data-opstudios="elementcollection"><a  href="#collection" aria-controls="collection" role="tab" data-toggle="tab" >Collection </a></li>
                                         <li data-opstudios="componetclasses"><a  href="#componetclasses" aria-controls="componetclasses" role="tab" data-toggle="tab" >Componet </a></li>
                                       
                                </ul>
                
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane" id="basicstyles" data-opstudios="basicclasses">
                        <div class="row m-r-0 m-l-0" style="background-color: #dbdbdb;">
                             <div class="col-md-4 p-t-10 comp-list">
                                     <div class="form-group p-l-20 p-t-10 p-r-20">
                                         <select class="form-control" data-typelsit="lists" style="background-color: white;    border: 1px solid #ccc;    color: #555;">

                                         </select>
                                     </div>
                                     <div class="list-group p-l-20 p-r-20" data-role="componentslist" data-typeclasses="basic">
                                     </div>
                                

                              </div>

                             <div class="col-md-8">
                                  <ul class="list-unstyled template-files existingclass clearfix" data-classeslsit="basic">

                                   </ul>
                               </div>
                           </div>
                    </div>
                     <div role="tabpanel" class="tab-pane" id="textcollectionstyles" data-opstudios="textcollection">
                           <ul class="list-unstyled template-files existingclass clearfix" data-classeslsit="text">

                           </ul>
                      </div>
                      
                      <div role="tabpanel" class="tab-pane" id="containercollectionstyles" data-opstudios="containercollections">
                           <ul class="list-unstyled template-files existingclass clearfix" data-classeslsit="container">

                           </ul>
                      
                      </div>
                      
                      <div role="tabpanel" class="tab-pane" id="collection" data-opstudios="elementcollection">
                           <ul class="list-unstyled template-files existingclass clearfix" data-classeslsit="elementcollection">

                           </ul>
                      
                      </div>
                      
                        <div role="tabpanel" class="tab-pane" id="componetclasses" data-opstudios="componetclasses">
                           <ul class="list-unstyled template-files existingclass clearfix" data-classeslsit="componetclasses">

                           </ul>
                      
                      </div>
                     
                      
                      
                    


              </div>
                </div>