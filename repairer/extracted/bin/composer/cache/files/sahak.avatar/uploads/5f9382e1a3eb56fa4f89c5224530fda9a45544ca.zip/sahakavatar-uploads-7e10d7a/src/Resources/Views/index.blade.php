@extends('cms::layouts.admin')
@section('content')
    <div>
        Upload Module
    </div>
@stop
@section('CSS')
@stop
@section('JS')
@stop

