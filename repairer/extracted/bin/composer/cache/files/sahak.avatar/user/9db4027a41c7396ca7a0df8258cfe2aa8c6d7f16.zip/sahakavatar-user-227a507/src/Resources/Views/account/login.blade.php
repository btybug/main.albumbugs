<div id="login">
    {{-- {!! sc('getCoreForm',['id' => '18','raw_id' => $user->id,'update' => true]) !!}--}}
</div>
