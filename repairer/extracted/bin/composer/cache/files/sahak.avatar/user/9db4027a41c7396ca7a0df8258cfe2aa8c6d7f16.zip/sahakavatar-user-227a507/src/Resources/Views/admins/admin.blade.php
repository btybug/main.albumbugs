@extends('cms::layouts.mTabs',['index'=>'admins_users'])

@section('parag')
    {!! Breadcrumbs::render('user-admin') !!}

@stop
@section('tab')

@stop
