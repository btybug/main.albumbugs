Welcome!
To activate account, please click link below:
{{ url('users/auth/activate/' . $username . '/' . $token) }}
