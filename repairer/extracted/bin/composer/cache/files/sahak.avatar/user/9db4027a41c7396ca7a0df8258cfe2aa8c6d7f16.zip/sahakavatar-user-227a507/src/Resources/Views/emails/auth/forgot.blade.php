Welcome!
To receive new password, please click link below:
{{ url('/users/auth/newpassword/' . $username . '/' . $token) }}
