Welcome!
Your new password:
{{ $password }}
