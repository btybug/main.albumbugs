@extends('layouts.admin')
@section('content')
    <ol class="breadcrumb">
        <li><a href="/">Dashboard</a></li>
        <li class="active">All Users</li>
    </ol>
    <div class="row">
        <div class="col-md-12">
            All users
        </div>
    </div>
@stop
