@extends('cms::layouts.mTabs',['index'=>'edit_profile'])
@section('tab')

@stop

@section("CSS")
    {!! HTML::style('libs/animate/css/animate.css') !!}
@stop
