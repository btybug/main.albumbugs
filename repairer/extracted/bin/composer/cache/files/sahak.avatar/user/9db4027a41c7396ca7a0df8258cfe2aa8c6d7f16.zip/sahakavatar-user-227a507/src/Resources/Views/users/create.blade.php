@extends('cms::layouts.admin')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <h2>Create User</h2>
        </div>
        [form id=8]
    </div>
@stop
@section('JS')

@stop
