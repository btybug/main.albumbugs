<?php
class Bar
{
    public function method()
    {
        // ...
    }
}
