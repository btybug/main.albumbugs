<?php
class Foo
{
    public function method()
    {
        // ...
    }
}
