<?php

if (!function_exists('__phpunit_run_isolated_test')) {
    throw new \Exception('boo');
}
